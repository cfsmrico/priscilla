% Saltykov sphere reconstruction method to estimate the 3D size distribution
% of air voids using the size distribution of 2D observed profile sizes as 
% input.  The output includes the mean observed circle radius, computed 
% sphere radius, and histograms of both the observed 2D and computed 3D radii.
%
% reconstructspheres plots the histograms using the Freedman-Diaconis 
% rule is used to estimate a binwidth.  The computed binwidth is written 
% to the Matlab Command Window.  This value may be a good starting point
% attempting to determine an appropriate binwidth.
%
% reconstructspheres(binwidth) takes in the variable binwidth and plots
% the distributions accordingly, where the units of binwidth is in microns. 
% Example: reconstructspheres(4) produces histograms with binwidth = 4 microns.
%
% reconstructspheres(binwidth,xmax) specifies the maximum x-limit on the
% plotted distributions, where the unit of xmax is microns.
% Example: reconstructspheres(4,160) produces histograms with binwidth = 
% 4 microns and a horizontal axis with range (0,160) microns.
%
% See also readimage and basicanalysis.
%
function reconstructspheres(varargin)

% If a binwidth is passed
if nargin > 0
    binwidth = varargin{1};
end

% If an maximum x-limit is pssed
if nargin > 1     
    XL2 = varargin{2};  
end

% Get "grayimage", "stats", and "ppmm" from the base workspace
grayimage = evalin('base','grayimage');
stats = evalin('base','stats');
ppmm = evalin('base','ppmm');


close all 

areapix = [stats.Area];         % number of pixels per object (vector)
areamm2 = areapix/(ppmm*ppmm);% area of each profile in mm^2 (vector)
diameterpix = 2*sqrt(areapix/pi);     % equivalent diameter of each object (vector) 
diametermic = 2*sqrt(areamm2/pi)*1000; %diameter of each profile in microns
radiimic = 1/2*diametermic;         %radius of each profile in microns

averageradmic = sum(radiimic)/length(radiimic);  % mean observed radius
% averagediammic = 2*averageradmic                % mean observed diameter


% If no binwidth is specified, use Freedman-Diaconis rule to estimate a 
% binwidth
if nargin == 0
    IQRradii = iqr(radiimic);       % interquartile range of radiimic
    binwidth = 2*IQRradii*length(radiimic)^(-1/3);
end


%binwidth = 5;                   % bin width in microns
r = min(radiimic):binwidth:max(radiimic);

% bin the elements of radiimic into 'r' equally spaced containers
[N,X] = hist(radiimic,r);
freqN = 1/(sum(N))*N;

% Get number density of void profiles on image
cropdim = 1/ppmm*size(grayimage);               % image dimensions [mm]
NA = length(radiimic)/(cropdim(1)*cropdim(2));  % number density of bubble
                                                % profiles [mm^-2]
                                                
                                                
figure2 = figure;
set(figure2,'Position',[133 921 562 345]);
NAr = 1/binwidth*NA.*freqN;
bar(X,NAr);
ylabel('Number density per mm^2','FontSize',14);
xlabel('Observed profile radii [\mum]','FontSize',14);
%xlim([0 150])
title('Distribution of observed bubble profiles','FontSize',16);
XL = xlim; YL = ylim;
XL(1) = 0; YL(1) = 0;
if nargin > 1
    XL(2) = XL2;
end
xlim(XL); ylim(YL);



%Rm = ceil(max(radiimic));          % maximum radius
nbins = length(r); 
Dr = binwidth;                      % width of each class of radii

NArorig = NAr;

rmod = [0 r];
r = rmod;
NARmod = [0 NAr];           % modify vector to include a bin with 0 radius

NAr = NARmod';


meanprofileradius = 1/sum(NAr)*sum(NAr.*r');  % mean observed radius in microns
disp(' ')
str = ['The mean observed profile radius is ', num2str(averageradmic), ' microns.'];
disp(str)



rm = max(r);                 % largest radius of the current working class

NArm = zeros(length(r),1);
NVR = zeros(length(r),1);

for k=1:length(NAr)-1
    
    % compute the numerical density of the largest spheres NVm
    NVm = NAr(length(NAr)-k+1)/(2*sqrt(2*(length(NAr)-k)-1)*Dr);
    NVR(length(NAr)-k+1) = NVm;      % store into a vector NV
    
    NArm = zeros(length(r),1);      % reset profile number density of rmax
    
    % compute number of profiles per section area
    for i=1:length(r)-k+1
        NArm(i) = NVm*2*(sqrt(rm^2-(r(i)-Dr)^2)-sqrt(rm^2-r(i)^2));
    end
    rm = rm-Dr;                     % new maximum radius
    
    NArm;
    NAr = NAr - NArm;               % get new profile number density
    
end


NV = sum(NVR);                      % sum under sphere histogram

maxfreq = max(NVR);
minfreq = min(NVR);
fR = 1/NV*NVR;                      % frequency of sphere radii



meansphereradius = 1/NV*sum(NVR.*r'); % mean radius of reconstructed bubbles
disp(' ')
str = ['The mean computed sphere radius is ', num2str(meansphereradius), ' microns.'];
disp(str)

%get total volume and total profile area in microns^2 or microns^3
radius = r';
Abox = NARmod'.*pi.*radius.^2;
Aboxtotal = sum(Abox);

Vbox = 4/3*pi*NVR.*radius.^3;
Vboxtotal = sum(Vbox);

% delete negative bins in NVR
for i=1:length(NVR)
    if NVR(i) < 0
        NVR(i) = 0;
    end
end

NV = sum(NVR);                      % sum under sphere histogram
meansphereradius = 1/NV*sum(NVR.*r');
meanspherediameter = 2*meansphereradius;



% Roughly estimate the median of the sphere radii.  The median will be used
% to estimate lognormal distribution parameters. If the binwidth is 
% inappropriate, this estimate will be inaccurate.
cumsumNVR = cumsum(NVR);
midpt = cumsumNVR(end)/2;
for i=1:length(cumsumNVR)
    if cumsumNVR(i) > midpt
        idx = i;
    break
    end
end
medianestupper = r(idx);
medianestlower = r(idx-1);
%medianRest = (medianestupper+medianestlower)/2;
medianRest = medianestupper;
medianDest = 2*medianRest;

% compute mu and sigma from the estimated median of sphere radii
muest = log(medianRest);
sigmaest = sqrt(2*(log(meansphereradius)-muest));


% plot estimated air void size distribution
figure;
bar(r,NVR);
set(gcf,'Position',[135 516 562 345]);
ylabel('Number density per mm^3','FontSize',14);
xlabel('Computed sphere radii [\mum]','FontSize',14);
XL = xlim; 
XL(1) = 0; 
if nargin > 1
    XL(2) = XL2;
end
xlim(XL); 
% % Uncomment the following lines to plot estimated lognormal distribution
% hold on
% rsm = 0:0.1:XL(2);
% YsphereR=lognpdf(rsm,muest,sigmaest);
% p5=plot(rsm,binwidth*NV.*YsphereR);
% set(p5,'Color','red');
% title('Distribution of reconstructed bubbles','FontSize',16);
YL = ylim;
YL(1) = 0;
ylim(YL);

disp(' ')
str = ['The binwidth is ', num2str(binwidth), ' microns.'];
disp(str)
disp(' ')
% % Uncomment the following lines to display lognormal parameters
% str = ['The estimated lognormal distribution parameters '];
% disp(str)
% str = ['for the sphere distrition are: '];
% disp(str)
% disp(' ')
% str = ['   MU = ', num2str(muest), ' microns and SIGMA = ' num2str(sigmaest) ' microns.'];
% disp(str)
% disp(' ')
