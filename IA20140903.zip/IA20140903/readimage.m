% Read a grayscale image for image analysis.  
% readimage(Filename) reads a grayscale image, where Filename is
% the name of the graphics file located in the current working directory.
% Example: readimage('ex1.tif') reads in an image located in
% the same directory as readimage.
%
% readimage(Filename,Folder) reads the image named Filename located in the 
% specified Folder.
% Example: readimage('ex1.tif','Images') reads in the image
% "ex1.tif" located in the directory "Images."
%
% readimage(Filename,Folder,'cr') initiates the interactive Crop Image Tool 
% that allows you to crop the image.
% Example: readimage('ex1.tif','Images','cr') allows you to crop the
% image 'ex1.tif.'  If you want to read and crop the image located in
% the current working directory, type 
% "readimage('exlocal.tif','','cr')".
%
% Basic information about the image is processed and written to the 
% base workspace.  The variables "grayimage", "pixsize", and "ppmm" are 
% assigned to the base workspace for use by the function basicanalysis.
% "grayimage" is a matrix containing the graylevels of each pixel,
% "pixsize" is the size of each pixel in mm, and "ppmm" is the resolution
% in pixels per millimeter.
%
% The Image Processing Toolbox must be installed to use this function.
% Type "ver" at the command prompt to determine which toolboxes are
% installed.
%
% The resolution of the image will be automatically determined.  The 
% function "readimage" assumes that the image resolution unit is in
% [pixels/inch]. If the image resolution unit is not in [pixels/inch], 
% then the variable "ppmm" [pixels/mm] must be modified in this function.
%
% See also basicanalysis and reconstructspheres.


function readimage(varargin)


% The user must pass the filename of the image
if nargin == 0
    error('A filename is a required input')
end

% If the optional Folder is not passed, then the path is the filename
if nargin == 1                       
    fpath = varargin{1};
end

% If a folder is passed, concatenate the folder and filename into a path
if nargin > 1
    fpath = strcat(varargin{2},'/',varargin{1});  
end


% Determine the resolution of the image in pixels per inch (dpi).  The
% resolution in the vertical and horizontal directions should be the same.
finfo = imfinfo(fpath);         
xR = finfo.XResolution;         % xR should be the image resolution in dpi
yR = finfo.YResolution;
if xR ~= yR
    disp('The vertical and horizontal resolution does not match.')
    disp('The analysis may not be valid.  Check the scanning resolution.')
end

mmpi = 25.4;                    % the number of mm per inch
ppmm = xR/mmpi;                 % ppmm is pixels per mm
assignin('base','ppmm',ppmm)    % write ppmm to the base workspace
psize = 25400/xR;               % psize is pixel size in microns
assignin('base','pixsize',psize)% write psize->pixsize to the workspace

fname = varargin{1};            % assign the filename to variable "fname"

% Display resolution infomation to the user
disp(' ')
str = ['The resolution of image "',fname, '" is ', num2str(xR), ' pixels/inch'];
disp(str)
str = ['or ', num2str(ppmm), ' pixels/mm.'];
disp(str)
str = ['The size of each pixel is ', num2str(psize), ' microns.'];
disp(' ')
disp(str)
disp(' ')


% Read image using function imread.  
airnocrop = imread(fpath);

% Display the grayscale image
figure;
imshow(airnocrop);

% If a 3rd argument is passed, the user wants to crop the image
if nargin == 3    
    disp('You have chosen to crop your image.  Drag a rectangular ')
    disp('region on the figure window and double click to crop image.')
    disp(' ')
    I = imcrop(airnocrop);
    assignin('base','grayimage',I);
    
    % Display the cropped grayscale image
    figure;
    imshow(I);
else

% Else the image is already ready to go
assignin('base','grayimage',airnocrop);

end

