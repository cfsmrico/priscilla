% Basic image analysis to determine the air content, specific surface, and 
% the Powers spacing factor of the air voids shown in a grayscale image.  
% The output is written to the Matlab Command Window.
%
% basicanalysis(paste_solids) takes in the variable paste_solids, where 
% paste_solids is the paste/solids ratio.
% Example: basicanalysis(0.8) specifies a paste/solids ratio of 0.8.
%
% basicanalysis(paste_solids,thresh) includes a user-defined
% input thresh, where thresh is the image threshold.  If thresh is not
% specified, then the threshold will be determined using Otsu's method.
% Type 'help graythresh' for more information on automatic thresholding.
%
% basicanalysis must be run after running the function readimage.
% The variables "grayimage", "pixsize", and "ppmm" are taken from the base
% workspace.
%
% See also readimage and reconstructspheres.

function basicanalysis(varargin)

% Get "grayimage" and "ppmm" from the base workspace
grayimage = evalin('base','grayimage');
ppmm = evalin('base','ppmm');


% The user must pass the paste/solids ratio as an argument
if nargin < 1
    error('basicanalysis requires a paste:solids ratio as input.')
end

% The first argument corresponds to paste_solids
paste_solids = varargin{1};

% If more than one argument is passed, the 2nd argument is the
% threshold
if nargin > 1
    thresh = varargin{2};  
end


cropdim = size(grayimage)/ppmm;        % dimensions of the image in mm
assignin('base','cropdim',cropdim)


% If the user does not specify a threshold, compute the threshold using
% Otsu's method.  The user may want to first compute the automatic 
% threshold and then adjust the binary image by matching the void 
% diameters in the grayscale image with the diameters of the corresponding 
% objects in the binary image.

if nargin < 2    
    thresh = graythresh(grayimage)*255;
end

assignin('base','threshold',thresh)

bw = im2bw(grayimage,thresh/255);

% Remove the smallest voids by selecting any cluster of white pixels that 
% contain less than or equal to a specified number "tinyobjects."  If you do
% not want to remove any white pixels, set tinyobjects = 0.  A cluster is
% defined using nearest neighbors for each pixel.  In 2D, a square pixel 
% has either 4 maximum neighbors or 8 maximum neighbors, depending on 
% whether or not you want to include neighbors at a diagonal.  Therefore,
% neigh=4 or neigh=8.  Store the new binary image into a matrix called bw2.
% Note that if tinyobjects=0, then bw2=bw.
% 
tinyobjects = 1;
neigh = 4;                              
bw2 = bwareaopen(bw,tinyobjects+1,neigh);
assignin('base','bw2',bw2)

figure;
imshow(bw2);

disp(' ')
str = ['The threshold is ', num2str(thresh), '.'];
disp(str)

% Find connected components in a binary image.  Set conn=4 or conn=8, which
% defines the number of maximum neighbors for a square pixel in 2D.  
conn = 4;
cc = bwconncomp(bw2,conn);      % connectivity, image size, number of  
                                % connected components, pixel index list
assignin('base','cc',cc)
                               
% Measures a set of properties for each connected component in cc
stats = regionprops(cc,'Area','Perimeter');
assignin('base','stats',stats)
% stats = regionprops(cc,'EquivDiameter','PixelIdxList','PixelList');

areapix = [stats.Area];         % number of pixels per object (vector)
areamm2 = [stats.Area]/(ppmm*ppmm);% area of each profile in mm^2 (vector)
diameterpix = 2*sqrt(areapix/pi);     % equivalent diameter of each object (vector) 
diametermic = 2*sqrt(areamm2/pi)*1000; %diameter of each profile in microns
radiimic = 1/2*diametermic;         %radius of each profile in microns

assignin('base','radiimic',radiimic)

% The fractional area content is the sum of the areas of each void divided
% by the area of the image
[m,n] = size(grayimage);
aircontent = sum(areapix)/(m*n)*100;
%aircontent = sum(areamm2)/(cropdim(1)*cropdim(2))*100;

disp(' ')
str = ['The air content is ', num2str(aircontent), ' percent.'];
disp(str)



%maxD = max(diameter);

Ptot = sum([stats.Perimeter]);     % perimeter in pixels
Atot = sum([stats.Area]);           % area in pixels^2
specsurfpix = Ptot/Atot*4/pi;       % specific surface in pixels^(-1)
specsurf = specsurfpix*ppmm;        % specific surface in mm^-1

disp(' ')
str = ['The specific surface is ', num2str(specsurf), ' mm^-1.'];
disp(str)

% spacing factor

p_A = paste_solids*(100-aircontent)/(aircontent); % paste:air ratio

disp(' ')
str = ['The paste/air ratio is ', num2str(p_A), '.'];
disp(str)

% Compute Powers spacing factor in mm
if p_A < 4.342
    Pspacef = p_A/specsurf;
else
    Pspacef = (3/specsurf)*(1.4*(1+p_A)^(1/3)-1);   
end

disp(' ')
str = ['The Powers spacing factor is ', num2str(Pspacef), ' mm.'];
disp(str)

